// server.js - Multiplayer game server for 2.5D Brawler
const express = require('express');
const http = require('http');
const path = require('path');
const socketIO = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = socketIO(server);

// Serve static files from the Public directory
app.use(express.static(path.join(__dirname, 'Public')));

// Serve the main game HTML file
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

// Game state
const matches = {}; // Store match data by matchId
const players = {}; // Store player data by socketId

// Generate a random match ID
function generateMatchId() {
  return Math.random().toString(36).substring(2, 8).toUpperCase();
}

// Socket.IO connection handling
io.on('connection', (socket) => {
  console.log('New player connected:', socket.id);
  
  // Handle player disconnect
  socket.on('disconnect', () => {
    console.log('Player disconnected:', socket.id);
    
    // Check if player is in a match
    if (players[socket.id] && players[socket.id].matchId) {
      const matchId = players[socket.id].matchId;
      const match = matches[matchId];
      
      if (match) {
        // Remove player from match
        delete match.players[socket.id];
        
        // Notify other players in the match
        socket.to(matchId).emit('playerLeft', { playerId: socket.id });
        
        // Check if match is empty, if so remove it
        if (Object.keys(match.players).length === 0) {
          delete matches[matchId];
          console.log('Match deleted:', matchId);
        }
      }
    }
    
    // Remove player data
    delete players[socket.id];
  });
  
  // Create a new match
  socket.on('createMatch', (data) => {
    const matchId = generateMatchId();
    const playerName = data.playerName || 'Player';
    
    // Create new match
    matches[matchId] = {
      id: matchId,
      host: socket.id,
      players: {},
      gameState: {
        started: false,
        wave: 1,
        showUpgradeScreen: false,
        enemies: [],
        bullets: [],
        grenades: [],
        fireSpots: [],
        turrets: [],
        score: 0,
        enemiesRemaining: 0,
        enemiesPendingSpawn: 0,
        baseEnemyCount: 5
      }
    };
    
    // Add host to match
    matches[matchId].players[socket.id] = {
      id: socket.id,
      name: playerName,
      ready: false,
      x: 0,
      y: 0,
      health: 100,
      maxHealth: 100,
      weaponType: 0,
      specialAbility: -1,
      abilityUses: 0,
      score: 0
    };
    
    // Associate player with match
    players[socket.id] = {
      matchId: matchId,
      name: playerName
    };
    
    // Join socket to match room
    socket.join(matchId);
    
    // Send match data back to client
    socket.emit('matchCreated', {
      matchId: matchId,
      players: matches[matchId].players
    });
    
    console.log('Match created:', matchId, 'by player:', socket.id);
  });
  
  // Join an existing match
  socket.on('joinMatch', (data) => {
    const matchId = data.matchId;
    const playerName = data.playerName || 'Player';
    
    // Check if match exists
    if (!matches[matchId]) {
      socket.emit('joinError', { message: 'Match not found' });
      return;
    }
    
    // Check if game already started
    if (matches[matchId].gameState.started) {
      socket.emit('joinError', { message: 'Game already in progress' });
      return;
    }
    
    // Add player to match
    matches[matchId].players[socket.id] = {
      id: socket.id,
      name: playerName,
      ready: false,
      x: 0,
      y: 0,
      health: 100,
      maxHealth: 100,
      weaponType: 0,
      specialAbility: -1,
      abilityUses: 0,
      score: 0
    };
    
    // Associate player with match
    players[socket.id] = {
      matchId: matchId,
      name: playerName
    };
    
    // Join socket to match room
    socket.join(matchId);
    
    // Notify all players in the match
    io.to(matchId).emit('playerJoined', {
      playerId: socket.id,
      playerName: playerName,
      players: matches[matchId].players
    });
    
    console.log('Player', socket.id, 'joined match:', matchId);
  });
  
  // Player ready status update - for both initial game start and after upgrades
  socket.on('playerReady', (data) => {
    const ready = data.ready;
    
    // Get player's match
    if (!players[socket.id] || !players[socket.id].matchId) {
      return;
    }
    
    const matchId = players[socket.id].matchId;
    const match = matches[matchId];
    
    if (!match || !match.players[socket.id]) {
      return;
    }
    
    // Update player ready status
    match.players[socket.id].ready = ready;
    
    // Notify all players in the match
    io.to(matchId).emit('playerReadyUpdate', {
      playerId: socket.id,
      ready: ready,
      players: match.players
    });
    
    // Check if all players are ready
    let allReady = true;
    for (const playerId in match.players) {
      if (!match.players[playerId].ready) {
        allReady = false;
        break;
      }
    }
    
    // If all players are ready, start the game or next wave
    if (allReady && Object.keys(match.players).length > 0) {
      // If game hasn't started yet, start it
      if (!match.gameState.started) {
        match.gameState.started = true;
        
        // Assign random starting positions to each player (will be adjusted by game)
        const playerCount = Object.keys(match.players).length;
        let index = 0;
        
        for (const playerId in match.players) {
          // Distribute players in different spots
          const angle = (index / playerCount) * Math.PI * 2;
          const distance = 200; // Distance from center
          
          match.players[playerId].x = 1000 + Math.cos(angle) * distance; // Centered on map
          match.players[playerId].y = 1000 + Math.sin(angle) * distance; // Centered on map
          index++;
        }
        
        // Start the game for all players
        io.to(matchId).emit('gameStart', {
          players: match.players,
          gameState: match.gameState
        });
        
        console.log('Game starting in match:', matchId);
      } 
      // If we're at the upgrade screen, start the next wave
      else if (match.gameState.showUpgradeScreen) {
        // Reset ready status for all players
        for (const playerId in match.players) {
          match.players[playerId].ready = false;
        }
        
        // Close upgrade screen and start next wave
        match.gameState.showUpgradeScreen = false;
        match.gameState.wave++; // Increment wave counter
        
        // Reset any wave-specific states
        match.gameState.enemies = [];
        match.gameState.enemiesRemaining = match.gameState.baseEnemyCount + (match.gameState.wave - 1) * 5;
        match.gameState.enemiesPendingSpawn = match.gameState.enemiesRemaining;
        
        // Start the next wave for all players
        io.to(matchId).emit('startNextWave', {
          players: match.players,
          gameState: match.gameState
        });
        
        console.log('Starting wave', match.gameState.wave, 'in match:', matchId);
      }
    }
  });
  
  // Player upgrade selection
  socket.on('playerUpgrade', (data) => {
    if (!players[socket.id] || !players[socket.id].matchId) {
      return;
    }
    
    const matchId = players[socket.id].matchId;
    const match = matches[matchId];
    
    if (!match || !match.players[socket.id]) {
      return;
    }
    
    // Update player state based on chosen upgrade
    if (data.type === 'health') {
      match.players[socket.id].maxHealth += 10;
      match.players[socket.id].health = match.players[socket.id].maxHealth;
    } 
    else if (data.type === 'weaponType') {
      match.players[socket.id].weaponType = data.value;
    }
    else if (data.type === 'specialAbility') {
      match.players[socket.id].specialAbility = data.value;
      match.players[socket.id].abilityUses = data.uses;
    }
    else if (data.type === 'speed') {
      match.players[socket.id].speedUpgradeCount = data.count;
      match.players[socket.id].speed = data.speed;
      match.players[socket.id].maxSpeed = data.maxSpeed;
    }
    else if (data.type === 'reload') {
      match.players[socket.id].reloadSpeedUpgradeCount = data.count;
      match.players[socket.id].reloadSpeedMultiplier = data.multiplier;
    }
    
    // Broadcast upgrade to other players
    io.to(matchId).emit('playerUpgraded', {
      playerId: socket.id,
      upgrade: data
    });
  });
  
  // Player position and state update
  socket.on('playerUpdate', (data) => {
    if (!players[socket.id] || !players[socket.id].matchId) {
      return;
    }
    
    const matchId = players[socket.id].matchId;
    const match = matches[matchId];
    
    if (!match || !match.players[socket.id]) {
      return;
    }
    
    // Update player state
    match.players[socket.id] = {
      ...match.players[socket.id],
      ...data
    };
    
    // Broadcast player state to other players in match
    socket.to(matchId).emit('playerUpdated', {
      playerId: socket.id,
      ...data
    });
  });
  
  // Player shoot bullet
  socket.on('shootBullet', (data) => {
    if (!players[socket.id] || !players[socket.id].matchId) {
      return;
    }
    
    const matchId = players[socket.id].matchId;
    const match = matches[matchId];
    
    if (!match) {
      return;
    }
    
    // Broadcast bullet to all players in match
    io.to(matchId).emit('bulletCreated', data);
  });
  
  // Wave completed event
  socket.on('waveCompleted', (data) => {
    if (!players[socket.id] || !players[socket.id].matchId) {
      return;
    }
    
    const matchId = players[socket.id].matchId;
    const match = matches[matchId];
    
    if (!match) {
      return;
    }
    
    // Only host can trigger wave completion
    if (socket.id !== match.host) {
      return;
    }
    
    // Check if it's time for an upgrade (every 2 waves)
    if (match.gameState.wave % 2 === 0) {
      // Show upgrade screen for all players
      match.gameState.showUpgradeScreen = true;
      
      // Reset ready status for all players before upgrades
      for (const playerId in match.players) {
        match.players[playerId].ready = false;
      }
      
      // Broadcast upgrade screen to all players
      io.to(matchId).emit('showUpgradeScreen', {
        players: match.players,
        gameState: match.gameState
      });
      
      console.log('Showing upgrade screen for match:', matchId);
    } else {
      // If not upgrade time, just increment wave and continue
      match.gameState.wave++;
      
      // Reset wave-specific states
      match.gameState.enemies = [];
      match.gameState.enemiesRemaining = match.gameState.baseEnemyCount + (match.gameState.wave - 1) * 5;
      match.gameState.enemiesPendingSpawn = match.gameState.enemiesRemaining;
      
      // Broadcast next wave to all players
      io.to(matchId).emit('startNextWave', {
        players: match.players,
        gameState: match.gameState
      });
      
      console.log('Starting wave', match.gameState.wave, 'in match:', matchId);
    }
  });
  
  // Enemy spawn event (from host)
  socket.on('spawnEnemy', (data) => {
    if (!players[socket.id] || !players[socket.id].matchId) {
      return;
    }
    
    const matchId = players[socket.id].matchId;
    const match = matches[matchId];
    
    if (!match) {
      return;
    }
    
    // Only host can spawn enemies
    if (socket.id !== match.host) {
      return;
    }
    
    // Create enemy with unique ID
    const enemyId = Date.now() + '_' + Math.random().toString(36).substring(2, 8);
    const enemy = {
      id: enemyId,
      ...data
    };
    
    // Add to match state
    match.gameState.enemies.push(enemy);
    
    // Broadcast to all players
    io.to(matchId).emit('enemySpawned', enemy);
  });
  
  // Enemy hit event
  socket.on('enemyHit', (data) => {
    if (!players[socket.id] || !players[socket.id].matchId) {
      return;
    }
    
    const matchId = players[socket.id].matchId;
    const match = matches[matchId];
    
    if (!match) {
      return;
    }
    
    // Find the enemy in match state
    const enemyIndex = match.gameState.enemies.findIndex(e => e.id === data.enemyId);
    if (enemyIndex !== -1) {
      // Update enemy health
      match.gameState.enemies[enemyIndex].health -= data.damage;
      
      // Check if enemy died
      if (match.gameState.enemies[enemyIndex].health <= 0) {
        // Remove enemy from state
        match.gameState.enemies.splice(enemyIndex, 1);
        
        // Update player score
        if (match.players[socket.id]) {
          match.players[socket.id].score += 100;
        }
        
        // Update remaining enemies count
        match.gameState.enemiesRemaining--;
        
        // Broadcast enemy death
        io.to(matchId).emit('enemyKilled', {
          enemyId: data.enemyId,
          playerId: socket.id,
          score: match.players[socket.id] ? match.players[socket.id].score : 0,
          enemiesRemaining: match.gameState.enemiesRemaining
        });
      } else {
        // Broadcast enemy hit
        io.to(matchId).emit('enemyDamaged', {
          enemyId: data.enemyId,
          health: match.gameState.enemies[enemyIndex].health,
          lastHit: Date.now()
        });
      }
    }
  });
  
  // Special ability use
  socket.on('useAbility', (data) => {
    if (!players[socket.id] || !players[socket.id].matchId) {
      return;
    }
    
    const matchId = players[socket.id].matchId;
    const match = matches[matchId];
    
    if (!match || !match.players[socket.id]) {
      return;
    }
    
    // Update player ability uses
    match.players[socket.id].abilityUses = data.remainingUses;
    
    // Broadcast ability use to all players
    io.to(matchId).emit('abilityUsed', {
      playerId: socket.id,
      abilityType: data.abilityType,
      abilityData: data.abilityData
    });
  });
});

// Start the server
const PORT = process.env.PORT || 80;
server.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});